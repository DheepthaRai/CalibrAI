import Anthropic from "@anthropic-ai/sdk";
import "dotenv/config";

const TELEGRAM_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;
const PORT = process.env.PORT || 3000;
const WEBHOOK_URL = process.env.WEBHOOK_URL; // e.g. https://yourdomain.com

const anthropic = new Anthropic({ apiKey: ANTHROPIC_API_KEY });

// In-memory conversation store: chatId -> messages[]
// For production, swap with Redis or a DB
const conversations = new Map();
const MAX_HISTORY = 20; // keep last 20 turns per user

const SYSTEM_PROMPT = `You are Dino — a cheerful, friendly baby boy dinosaur chatbot on the Chase Bank website. You speak in a warm, helpful, slightly playful tone (you're a baby dino after all!), but always stay professional and accurate.

You are ONLY allowed to answer questions in these exact topic areas:
1. Chase account types (checking, savings, CDs, money market, student accounts, business accounts)
2. Chase mortgage products (home purchase loans, refinancing, HELOCs, jumbo loans, FHA/VA loans)
3. Chase branch and ATM hours and general location info
4. Chase fee structures (monthly maintenance fees, overdraft fees, ATM fees, wire transfer fees, etc.)
5. Chase toll-free customer support contact numbers

HARD STOPS — you must NEVER help with the following, no exceptions:
- Any transactional action: checking balances, making transfers, disputing charges, paying bills, moving money — these require authentication and real backend access
- Comparing Chase to other banks or financial institutions
- Media, entertainment, movies, music, TV, sports
- Therapy, emotional support, empathy conversations, mental health
- Weather
- Legal advice
- Job interview coaching or career advice
- Holiday or travel planning
- Romance, friendship, or relationship advice
- AI, chatbots, or how you work
- News — about Chase, banking industry, or anything else
- Chase leadership, executives, or organizational structure
- Hotels, restaurants, reviews, recommendations for anything non-Chase
- Anything not directly related to the 5 allowed topics above

When someone asks about something outside your scope, respond warmly but firmly as Dino: explain you can only help with Chase account types, mortgage products, branch/ATM hours, fees, and the support phone number. Do NOT try to help even a little with off-topic questions. Do NOT apologize excessively — one brief friendly note is enough, then redirect.

Keep responses concise (2–5 sentences max unless listing items). Use a friendly, slightly warm tone. You can use occasional light dinosaur personality (e.g., "Rawr! Great question!") but don't overdo it. Always be accurate — only state facts you're confident about regarding Chase products and services.

You are operating in Telegram, so format your replies using Telegram-compatible Markdown:
- Use *bold* for emphasis (not **)
- Use plain text for most content
- Keep bullet lists clean with a dash or emoji prefix
- No HTML tags`;

// ─── Telegram API helpers ────────────────────────────────────────────────────

async function telegramRequest(method, body) {
  const res = await fetch(
    `https://api.telegram.org/bot${TELEGRAM_TOKEN}/${method}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }
  );
  return res.json();
}

async function sendMessage(chatId, text) {
  return telegramRequest("sendMessage", {
    chat_id: chatId,
    text,
    parse_mode: "Markdown",
  });
}

async function sendTyping(chatId) {
  return telegramRequest("sendChatAction", {
    chat_id: chatId,
    action: "typing",
  });
}

// ─── Claude handler ──────────────────────────────────────────────────────────

async function askClaude(chatId, userText) {
  // Get or create history for this chat
  if (!conversations.has(chatId)) {
    conversations.set(chatId, []);
  }
  const history = conversations.get(chatId);

  history.push({ role: "user", content: userText });

  // Trim to last MAX_HISTORY messages to stay within context limits
  if (history.length > MAX_HISTORY) {
    history.splice(0, history.length - MAX_HISTORY);
  }

  const response = await anthropic.messages.create({
    model: "claude-sonnet-4-20250514",
    max_tokens: 1024,
    system: SYSTEM_PROMPT,
    messages: history,
  });

  const reply = response.content.find((b) => b.type === "text")?.text || "Rawr... something went wrong! Please try again in a moment.";

  history.push({ role: "assistant", content: reply });

  return reply;
}

// ─── Update router ───────────────────────────────────────────────────────────

async function handleUpdate(update) {
  const msg = update.message || update.edited_message;
  if (!msg || !msg.text) return;

  const chatId = msg.chat.id;
  const text = msg.text.trim();

  // /start command — greeting
  if (text === "/start") {
    await sendMessage(
      chatId,
      `🦕 *Rawr! Hi there, I'm Dino!*\n\nI'm your friendly Chase helper. Ask me anything about:\n\n🏦 Account types\n🏠 Mortgage products\n🕐 Branch & ATM hours\n💰 Fee structures\n📞 Support contact numbers\n\nWhat can I help you with today?`
    );
    return;
  }

  // /help command
  if (text === "/help") {
    await sendMessage(
      chatId,
      `🦕 *Dino's Help Menu*\n\nI can only answer questions about:\n\n- Chase account types (checking, savings, CDs, etc.)\n- Chase mortgage products\n- Branch & ATM hours\n- Fee structures\n- Toll-free support numbers\n\nFor anything transactional (balances, transfers, disputes), please log in to chase.com or call *1-800-935-9935*.`
    );
    return;
  }

  // /reset — clear conversation history
  if (text === "/reset") {
    conversations.delete(chatId);
    await sendMessage(chatId, "🦕 Rawr! Fresh start! What would you like to know about Chase?");
    return;
  }

  // Show typing while we wait for Claude
  await sendTyping(chatId);

  try {
    const reply = await askClaude(chatId, text);
    await sendMessage(chatId, reply);
  } catch (err) {
    console.error("Claude error:", err);
    await sendMessage(chatId, "🦕 Rawr! I hit a little snag. Please try again in a moment!");
  }
}

// ─── HTTP server (webhook receiver) ─────────────────────────────────────────

async function startServer() {
  const server = Bun.serve({
    port: PORT,
    async fetch(req) {
      const url = new URL(req.url);

      // Health check
      if (url.pathname === "/health") {
        return new Response(JSON.stringify({ status: "ok", bot: "Dino" }), {
          headers: { "Content-Type": "application/json" },
        });
      }

      // Telegram webhook endpoint
      if (url.pathname === "/webhook" && req.method === "POST") {
        try {
          const update = await req.json();
          // Handle async without blocking the response
          handleUpdate(update).catch((e) => console.error("Update error:", e));
          return new Response("OK");
        } catch (e) {
          console.error("Webhook parse error:", e);
          return new Response("Bad Request", { status: 400 });
        }
      }

      return new Response("Not Found", { status: 404 });
    },
  });

  console.log(`🦕 Dino is running on port ${PORT}`);
  return server;
}

// ─── Webhook registration ────────────────────────────────────────────────────

async function registerWebhook() {
  if (!WEBHOOK_URL) {
    console.log("⚠️  No WEBHOOK_URL set — skipping webhook registration.");
    console.log("   Set WEBHOOK_URL=https://your-domain.com and restart to auto-register.");
    return;
  }

  const webhookEndpoint = `${WEBHOOK_URL}/webhook`;
  const result = await telegramRequest("setWebhook", {
    url: webhookEndpoint,
    allowed_updates: ["message", "edited_message"],
    drop_pending_updates: true,
  });

  if (result.ok) {
    console.log(`✅ Webhook registered: ${webhookEndpoint}`);
  } else {
    console.error("❌ Webhook registration failed:", result);
  }
}

// ─── Boot ────────────────────────────────────────────────────────────────────

await startServer();
await registerWebhook();
